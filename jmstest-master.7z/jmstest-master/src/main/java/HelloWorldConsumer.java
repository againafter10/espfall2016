import org.apache.activemq.ActiveMQConnectionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jms.*;

public class HelloWorldConsumer implements Runnable, ExceptionListener {


    private static final Logger logger = LoggerFactory.getLogger(HelloWorldConsumer.class);


    public void run() {
        try {
            ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory("vm://localhost");

            Connection connection = connectionFactory.createConnection();
            connection.start();

            connection.setExceptionListener(this);

            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

            Destination destination = session.createQueue("TEST.FOO");

            MessageConsumer consumer = session.createConsumer(destination);

            Message message = consumer.receive(1000);

            if (message instanceof TextMessage) {
                TextMessage textMessage = (TextMessage) message;
                String txt = textMessage.getText();
                System.out.println("Received: " + txt);
            } else {
                System.out.println("Received: " + message);
            }

            consumer.close();
            session.close();
            connection.close();
        } catch (JMSException e) {
            System.out.println("Cought: " + e);
            e.printStackTrace();
        }

    }

    public void onException(JMSException exception) {
        System.out.println("JMS Exception occured. Shutting down client");
    }

}

