import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jms.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;



public class Consumer implements Runnable {

    private static MessageConsumer consumer;


    private static final Logger logger = LoggerFactory.getLogger(Consumer.class);


    public void run() {
        try {
            Message message = consumer.receive();
            if (message instanceof TextMessage) {
                System.out.println("Received message: " + ((TextMessage) message).getText());
            }
        } catch (JMSException e1) {
            e1.printStackTrace();
        }

    }


    public static void main(String[] args) {
        try {
            logger.info("Start consumer");
            ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory("tcp://localhost:6616");
            Connection connection = connectionFactory.createConnection();
            connection.start();
            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            consumer = session.createConsumer(session.createQueue("TEST.FOO"));

            //check every 500ms queue
            ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();
            service.scheduleWithFixedDelay(new Consumer(), 0, 500, TimeUnit.MILLISECONDS);
            System.out.println("Something got executed");
        } catch (JMSException e) {
            e.printStackTrace();
        }

    }

}

