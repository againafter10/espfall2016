import org.apache.activemq.ActiveMQConnectionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jms.*;

/**
 * @author <a href="mailto:lobanovskiy.evgeniy@otr.ru" >Evgeny Lobanovsky</a>
 */

public class Produser {

    private static final Logger logger = LoggerFactory.getLogger(Produser.class);

    public static void main(String[] args) {
        try {
            logger.info("Start producer");
            ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory("tcp://localhost:6616");
            Connection connection = connectionFactory.createConnection();
            connection.start();

            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

            MessageProducer producer = session.createProducer(session.createQueue("TEST.FOO"));
            producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
                        
            String text = "Hello world! From: " + Thread.currentThread().getName() + " : " ;
            TextMessage message = session.createTextMessage();

            for (int i = 1; i <= 10; i++) {
                message.setText("i = " + i);
                producer.send(message);
                System.out.println("Sent message " + message.getText());
            }
            connection.close();

        } catch (JMSException e) {
            e.printStackTrace();
        }
    }
}
