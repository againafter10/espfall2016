package org.rest.twitterapp;

import oauth.signpost.OAuthConsumer;
import oauth.signpost.commonshttp.CommonsHttpOAuthConsumer;
 
import org.apache.commons.io.IOUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
 
 
public class reTweet {
 
	  static String AccessToken = "780539740785299456-7HtD6BqnemBxvtGR5EMJODpSlKUwxRH";
	  static String AccessSecret = "VbFFoVxf8oV1LTh19bBYGUypNref9jns0Mb040TClip09";
	  static String ConsumerKey = "cmHZIXj8dWRcgJOBKfjFt4fzT";
	  static String ConsumerSecret = "FROl68xM5q2KUzxKwrGK5uRwM5khakpQEgTUNM4FjG1yIOfxFg";
 
	
	public static void main(String[] args) throws Exception {
		OAuthConsumer consumer = new CommonsHttpOAuthConsumer(
                ConsumerKey,
                ConsumerSecret);
		
        consumer.setTokenWithSecret(AccessToken, AccessSecret);
        //url to Post/ReTweet Bill Gates tweet
        HttpPost request = new HttpPost("https://api.twitter.com/1.1/statuses/retweet/781233434295463936.json");
        consumer.sign(request);
 
        HttpClient client = new DefaultHttpClient();
        HttpResponse response = client.execute(request);
 
        int statusCode = response.getStatusLine().getStatusCode();
        System.out.println("Status Line"+ response.getStatusLine());
        System.out.println("New status code="+statusCode + ":" + response.getStatusLine().getReasonPhrase());
        System.out.println(IOUtils.toString(response.getEntity().getContent()));
	}
}